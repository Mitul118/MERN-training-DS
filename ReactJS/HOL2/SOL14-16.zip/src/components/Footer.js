import React from "react"

function Footer() {
    return (
      <footer>
        <p className='footer--copyright'>&copy;2022 Gupta development. All rights reserved</p>
      </footer>
    )
}

export default Footer