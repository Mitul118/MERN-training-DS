ReactDOM.render(
    // <p>Hi, my name is Mitul Gupta!</p>,
    <div><h1>React Features</h1>
        <ul>
            <li>JSX</li>
            <li>Components</li>
            <li>Virtual DOM</li>
            <li>Simplicity</li>
            <li>Performance</li>
        </ul>
    </div>,
    document.getElementById("root")
    // document.querySelector("div")
)