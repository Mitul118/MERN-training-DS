ReactDOM.render(
    <p>Hi, my name is Mitul Gupta!</p>,
    document.querySelector("div")
)