import React from 'react'

function App()
{
    return(
        <div>
            <nav>
                <img src='images/airbnb-logo.png' alt='' />

            </nav>
        </div>
    )
}
export default App